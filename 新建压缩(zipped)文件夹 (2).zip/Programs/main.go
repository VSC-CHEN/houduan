/*
 * @Author: git config SnowFish && git config 3200401354@qq.com
 * @Date: 2022-11-16 09:47:01
 * @LastEditors: git config SnowFish && git 3200401354@qq.com
 * @LastEditTime: 2022-11-17 11:20:35
 * @FilePath: \Memo_frame\main.go
 * @Description:
 *
 * Copyright (c) 2022 by snow-fish 3200401354@qq.com, All Rights Reserved.
 */
 package main

 import (
	 // "demo/CSV"
	 Programs "debt/Programs"
 )
 
 func main() {
	 debt := Programs.NewDebt()
	 debt.MainMenu()
 }
 